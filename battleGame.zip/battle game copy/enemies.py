import lootTables

class skeleton:
    lootTable = lootTables.skeletonLoot
    
    maxHealth = 10
    health = 10
    damage = 6
    incDamage = 0
    accuracy = 14
    dodge = 2
    incDamaged = 0
    defence = 1