# Fun-Rouguelike

This is a text-based rouguelike game I am making in python, complete with RNG, loot tables, and no AI used.

## Status

This game is already playable, but I am still working on making it better. There is currently a skeleton room and a chest room in the game.