import loot.chest as chest
import lootTables
import functions
import base
import loot.current as current

strength = current.strength
luck = current.luck
defence = current.luck
dodge = current.luck
accuracy = current.luck

print()

while True:
    functions.getroom()