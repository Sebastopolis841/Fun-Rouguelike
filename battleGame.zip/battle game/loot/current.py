import base

strength = base.strength
luck = base.luck
defence = base.defence
dodge = base.dodge
accuracy = base.accuracy
health = base.health
incDamage = 0
piercing = False
thorns = 0
incDamaged = 0


class weapon:
    damage = 0
    incDamage = 0
    piercing = False

class boots:
    defence = 0
    dodge = 0

class pants:
    defence = 0

class helmet:
    defence = 0

class chestplate:
    defence = 0
    thorns = 0

class amulet:
    damage = 0
    incDamage = 0
    dodge = 0

class enemy:
    maxHealth = 0
    health = 0
    damage = 0
    incDamage = 0
    accuracy = 0
    dodge = 0
    incDamaged = 0