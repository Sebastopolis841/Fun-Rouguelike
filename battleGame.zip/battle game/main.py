import functions

print()

while True:
    functions.getroom()