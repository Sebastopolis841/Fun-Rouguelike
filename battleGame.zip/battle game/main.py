import functions

print()

while True:
    try:
        while True:
            functions.getroom()
    except KeyboardInterrupt:
        print("\n\nThere is no escape...\n")