import functions

print()

while True:
    try:
        while True:
            functions.getroom()
    except KeyboardInterrupt:
        print("\nThere is no escape...\n")